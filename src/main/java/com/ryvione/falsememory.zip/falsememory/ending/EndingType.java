package com.ryvione.falsememory.ending;

public enum EndingType {
    VICTORY,
    DEFEAT,
    DRAW
}